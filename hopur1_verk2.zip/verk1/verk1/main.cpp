#include <QCoreApplication>
#include <iostream>
#include "ui.h"


int main()
{
    UI temp;
    temp.NextStep();
}

