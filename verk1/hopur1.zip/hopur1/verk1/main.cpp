#include <QCoreApplication>
#include <iostream>
#include "Scientist.h"
#include "ui.h"


int main(){
    UI temp;
    temp.start();
}

